
# Game "15" for Flipper Zero

Logic game [Wikipedia](https://en.wikipedia.org/wiki/15_puzzle)

![Game screen](images/Game15.png)

![Restore game](images/Game15Restore.png)

![Popoup](images/Game15Popup.png)

FAP file for firmware 0.69.1
