ADD_SCENE(wifi_deauther, start, Start)
ADD_SCENE(wifi_deauther, console_output, ConsoleOutput)
ADD_SCENE(wifi_deauther, text_input, TextInput)
