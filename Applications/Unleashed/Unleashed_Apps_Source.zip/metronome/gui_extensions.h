void elements_button_top_right(Canvas* canvas, const char* str);

void elements_button_top_left(Canvas* canvas, const char* str);
