#ifndef _TOTP_COMMON_TYPES_H_
#define _TOTP_COMMON_TYPES_H_

#define LOGGING_TAG "TOTP APP"
#define CRYPTO_KEY_SLOT 2

#endif
