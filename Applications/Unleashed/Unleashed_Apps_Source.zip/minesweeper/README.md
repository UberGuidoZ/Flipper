# Minesweeper

This is a Minesweeper implementation for the Flipper Zero device.

![screenshot](img/screenshot.png)

## Controls

- Arrow buttons to move
- Push center button to open field
- Hold center button to toggle flag

## Compiling

```
./fbt firmware_minesweeper
```
