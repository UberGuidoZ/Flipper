ADD_SCENE(dtmf_dolphin, start, Start)
ADD_SCENE(dtmf_dolphin, dialer, Dialer)