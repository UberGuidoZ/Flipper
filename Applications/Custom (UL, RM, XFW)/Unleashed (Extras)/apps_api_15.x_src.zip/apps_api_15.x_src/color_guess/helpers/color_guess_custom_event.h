#pragma once

typedef enum {
    ColorGuessCustomEventStartscreenUp,
    ColorGuessCustomEventStartscreenDown,
    ColorGuessCustomEventStartscreenLeft,
    ColorGuessCustomEventStartscreenRight,
    ColorGuessCustomEventStartscreenOk,
    ColorGuessCustomEventStartscreenBack,
    ColorGuessCustomEventColorSetUp,
    ColorGuessCustomEventColorSetDown,
    ColorGuessCustomEventColorSetLeft,
    ColorGuessCustomEventColorSetRight,
    ColorGuessCustomEventColorSetOk,
    ColorGuessCustomEventColorSetBack,
    ColorGuessCustomEventPlayUp,
    ColorGuessCustomEventPlayDown,
    ColorGuessCustomEventPlayLeft,
    ColorGuessCustomEventPlayRight,
    ColorGuessCustomEventPlayOk,
    ColorGuessCustomEventPlayBack,
} ColorGuessCustomEvent;