# SNAKE 2.0

A new version of Snake Game.

![Snake_2.0](https://github.com/Willzvul/Snake_2.0/blob/main/Snake%202.0.png)


## Features

1. Pause of game proccess
2. Possibility of speed Up by holding the arrows
3. Snake has a head.
4. The target is an apple
5. Complete progress bar

## Building FAP

https://fap.playmean.xyz/Willzvul/Snake_2.0

## Links

Special thanks for *.c file in https://github.com/DarkFlippers/unleashed-firmware.git

## Free Beer

You can support me by using this link:
(only RU payments accepted) 
https://yoomoney.ru/to/410018138145748/100