# flipper-zero_ios-bluetooth-trigger
A Bluetooth trigger / intervalometer for the flipper zero
