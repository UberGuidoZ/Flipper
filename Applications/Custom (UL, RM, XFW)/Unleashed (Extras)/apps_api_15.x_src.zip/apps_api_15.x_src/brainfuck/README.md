# FlipperZeroBrainfuck

Brainfuck interpreter and editor for the F0.  
Supports text inputs and outputs.  
Blue LED indicates program is running.  

![Screenshot-20230214-180839](https://user-images.githubusercontent.com/16545187/218821549-c024fee3-ae74-49ce-8e3d-da7aed88e62d.png)

![Screenshot-20230214-180942](https://user-images.githubusercontent.com/16545187/218821617-67a5db12-bbeb-4e78-8d69-01ca6fa65650.png)
