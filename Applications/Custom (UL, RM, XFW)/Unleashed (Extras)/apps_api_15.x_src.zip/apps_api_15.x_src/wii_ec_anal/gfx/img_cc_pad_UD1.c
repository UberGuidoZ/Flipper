// ##########
// ##########
// ####..####
// ####..####
// ####..####
// ##########
// ##########

#include "images.h"

const image_t  img_cc_pad_UD1 = { 5, 7, false, 5, 0, {
	0xFF, 0xF7, 0xBD, 0xFF, 0xE0
}};
