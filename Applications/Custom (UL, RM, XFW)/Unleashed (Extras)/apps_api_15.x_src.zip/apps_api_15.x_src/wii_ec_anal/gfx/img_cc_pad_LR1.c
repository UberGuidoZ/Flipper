// ##############
// ##############
// ####......####
// ##############
// ##############

#include "images.h"

const image_t  img_cc_pad_LR1 = { 7, 5, false, 5, 0, {
	0xFF, 0xFF, 0x1F, 0xFF, 0xE0
}};
