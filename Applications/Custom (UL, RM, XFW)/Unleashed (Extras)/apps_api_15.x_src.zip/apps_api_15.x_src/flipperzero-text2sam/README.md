- Type in a message and press the back button (or select save and press back at the text preview)
- SAM will say the message and the app will exit.

Made by combining code from the [caesarcipher (panki27)](https://github.com/panki27/caesar-cipher) and [SAM (ctoth)](https://github.com/ctoth/SAM) Flipper applications
