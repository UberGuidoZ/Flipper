# Flipper Zero music tracker
-=-=- MVP Stage: minimum viable player -=-=-

[>Get latest build<](https://nightly.link/DrZlo13/flipper-zero-music-tracker/workflows/build_dev/master/zero_tracker.fap.zip)
