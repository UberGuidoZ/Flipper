Flipper Zero BT Serial Example App
