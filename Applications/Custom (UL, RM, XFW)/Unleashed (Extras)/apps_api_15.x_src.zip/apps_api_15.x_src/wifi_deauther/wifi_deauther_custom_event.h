#pragma once

typedef enum {
    WifideautherEventRefreshConsoleOutput = 0,
    WifideautherEventStartConsole,
    WifideautherEventStartKeyboard,
} WifideautherCustomEvent;
