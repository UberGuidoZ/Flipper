typedef enum {
    TttMultiCustomEventReserved = 100,

    TttMultiCustomEventGameMove,
    TttMultiCustomEventGameFinish,
} TttMultiCustomEvent;
