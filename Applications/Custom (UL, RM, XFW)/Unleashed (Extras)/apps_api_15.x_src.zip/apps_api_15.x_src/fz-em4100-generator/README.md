# fz-em4100-generator [![FlipC.org](https://flipc.org/Milk-Cool/fz-em4100-generator/badge)](https://flipc.org/Milk-Cool/fz-em4100-generator)
A program that generates universal keys from a EM4100 key

## Installing
Click the FAP badge, connect your flipper and click "Install".
