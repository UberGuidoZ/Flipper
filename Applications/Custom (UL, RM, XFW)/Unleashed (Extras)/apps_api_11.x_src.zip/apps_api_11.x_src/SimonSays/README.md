# FlipperZero-SimonSays
## Think you can beat Simon?
![Image of dolphin saying Simon Says](Simon_Says_Flipper.png "Image of dolphin saying Simon Says")

![Main Menu showing text that says "Welcome to Simon Says. Press OK to start"](Screenshot_MainMenu.png "Main Menu showing text that says Welcome to Simon Says. Press OK to start") ![Image of Dolphin telling the sequence](Screenshot_InGame.png "Image of Dolphin telling the sequence")


 ## Controls
 - LED indicator turns red when Simon is speaking
 - Use DPAD to match Simon's sequence

 ## Coming Next
 - Difficulty Mode
 - Proper Main Menu
 - Sound effects (the visually impaired can play too!)
 - Vibration effects (the hearing impaired can play too!)
 - Better animations and sound effects