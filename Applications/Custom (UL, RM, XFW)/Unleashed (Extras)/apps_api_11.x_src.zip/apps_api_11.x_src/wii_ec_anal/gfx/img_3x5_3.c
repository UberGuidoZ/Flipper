// ######
// ....##
// ..####
// ....##
// ######

#include "images.h"

const image_t  img_3x5_3 = { 3, 5, false, 2, 0, {
	0xE5, 0x9E
}};
