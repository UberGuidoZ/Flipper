// ##....
// ##..##
// ######
// ....##
// ....##

#include "images.h"

const image_t  img_3x5_4 = { 3, 5, false, 2, 0, {
	0x97, 0x92
}};
