# FlipperZero-Etch-A-Sketch
Turn the Flipper Zero into an Etch A Sketch

This is a modification of the original paint app.

![](Screenshot.png)

 ## Changes
 - LED indicator turns red when draw mode is enabled
 - Pressing and holding the DPad will continously draw
 - Vibration effects added for mechanical feedback
 - Audio cues added for feedback
 - Smaller brush size for more creativity