ADD_SCENE(scope, start, Start)
ADD_SCENE(scope, run, Run)
ADD_SCENE(scope, setup, Setup)
ADD_SCENE(scope, about, About)
